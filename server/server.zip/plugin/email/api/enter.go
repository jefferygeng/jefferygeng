package api

type ApiGroup struct {
	EmailApi
}

var ApiGroupApp = new(ApiGroup)
