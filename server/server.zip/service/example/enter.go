package example

type ServiceGroup struct {
	FileUploadAndDownloadService
	CustomerService
	ExcelService
}
