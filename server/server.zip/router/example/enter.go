package example

type RouterGroup struct {
	CustomerRouter
	ExcelRouter
	FileUploadAndDownloadRouter
}
